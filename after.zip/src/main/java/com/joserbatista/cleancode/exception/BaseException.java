package com.joserbatista.cleancode.exception;

public abstract class BaseException extends Exception {

    BaseException(String message) {
        super(message);
    }
}
