package com.joserbatista.cleancode.exception;

public class NoSessionsApprovedException extends BaseException {

    public NoSessionsApprovedException(String message) {
        super(message);
    }
}
