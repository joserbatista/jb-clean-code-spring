package com.joserbatista.cleancode.exception;

public class ArgumentNullException extends BaseException {

    public ArgumentNullException(String message) {
        super(message);
    }
}
