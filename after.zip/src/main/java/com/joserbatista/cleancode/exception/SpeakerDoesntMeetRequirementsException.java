package com.joserbatista.cleancode.exception;

public class SpeakerDoesntMeetRequirementsException extends BaseException {

    public SpeakerDoesntMeetRequirementsException(String message) {
        super(message);
    }
}
