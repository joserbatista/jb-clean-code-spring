package com.joserbatista.cleancode.domain;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;


@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WebBrowser {

    BrowserName name;
    int majorVersion;

    public enum BrowserName {
        CHROME,
        DOLPHIN,
        FIREFOX,
        INTERNET_EXPLORER,
        KONQUEROR,
        LINX,
        OPERA,
        SAFARI,
        UNKNOWN

    }
}