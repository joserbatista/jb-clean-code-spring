package com.joserbatista.cleancode.controller.mapper;

import com.joserbatista.cleancode.controller.dto.SpeakerDto;
import com.joserbatista.cleancode.domain.Speaker;
import org.springframework.stereotype.Component;

@Component
public class SpeakerMapper {

    public Speaker toSpeaker(SpeakerDto speakerDto) {
        // Dummy Implementation
        return null;
    }

    public SpeakerDto toSpeakerDto(Speaker speaker) {
        // Dummy Implementation
        return null;
    }
}
