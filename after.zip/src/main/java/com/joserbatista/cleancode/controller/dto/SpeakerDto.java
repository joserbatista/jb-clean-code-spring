package com.joserbatista.cleancode.controller.dto;

import java.util.List;

public record SpeakerDto(
    Long departmentId,
    String firstName,
    String lastName,
    String email,
    int exp,
    boolean hasBlog,
    String blogURL,
    WebBrowserDto browser,
    List<String> certifications,
    String employer,
    int registrationFee,
    List<SessionDto> sessions
) {

    private class SessionDto {}


    private class WebBrowserDto {}
}