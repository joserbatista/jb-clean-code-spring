package com.joserbatista.cleancode.controller;

import com.joserbatista.cleancode.controller.dto.SpeakerDto;
import com.joserbatista.cleancode.controller.mapper.SpeakerMapper;
import com.joserbatista.cleancode.domain.Speaker;
import com.joserbatista.cleancode.exception.BaseException;
import com.joserbatista.cleancode.service.SpeakerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/speaker")
@Validated
public class SpeakerController implements SpeakerApi {

    private static final Logger log = LoggerFactory.getLogger(SpeakerController.class);

    private final SpeakerService service;
    private final SpeakerMapper mapper;

    @Autowired
    public SpeakerController(SpeakerService service, SpeakerMapper mapper) {
        this.service = service;
        this.mapper = mapper;
    }

    @Override
    public ResponseEntity<SpeakerDto> register(SpeakerDto speakerDto) throws BaseException {

        Speaker speaker = this.mapper.toSpeaker(speakerDto);
        Speaker createdSpeaker = this.service.register(speaker);
        log.trace("Speaker created with id {}", createdSpeaker.getId());

        SpeakerDto speakDto = this.mapper.toSpeakerDto(createdSpeaker);

        return ResponseEntity.ok(speakDto);
    }

    @Override
    public ResponseEntity<SpeakerDto> findById(Long id) {
        Speaker speaker = this.service.findById(id);
        SpeakerDto speakDto = this.mapper.toSpeakerDto(speaker);

        return ResponseEntity.ok(speakDto);
    }
}