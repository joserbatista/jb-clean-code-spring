package com.joserbatista.cleancode.service;

import com.joserbatista.cleancode.domain.Session;
import com.joserbatista.cleancode.domain.Speaker;
import com.joserbatista.cleancode.domain.WebBrowser;
import com.joserbatista.cleancode.exception.ArgumentNullException;
import com.joserbatista.cleancode.exception.BaseException;
import com.joserbatista.cleancode.exception.NoSessionsApprovedException;
import com.joserbatista.cleancode.exception.SpeakerDoesntMeetRequirementsException;
import com.joserbatista.cleancode.repository.SpeakerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
public class SpeakerService {

    private final SpeakerRepository repository;
    private final SpeakerValidator validator;

    @Autowired
    public SpeakerService(SpeakerRepository repository, SpeakerValidator validator) {
        this.repository = repository;
        this.validator = validator;
    }

    public Speaker register(Speaker speaker) throws BaseException {
        this.validator.throwIfInvalidSpeaker(speaker);
        return this.repository.save(speaker);
    }

    public Speaker findById(Long id) {
        return this.repository.get(id);
    }

    @Component
    public static class SpeakerValidator {

        private static final List<String> PREFERRED_EMPLOYERS = List.of("Microsoft", "Google", "Fog Creek Software", "37Signals");
        private static final List<String> OLD_TECHNOLOGIES = List.of("Cobol", "Punch Cards", "Commodore", "VBScript");
        private static final List<String> ANCIENT_DOMAINS = List.of("aol.com", "hotmail.com", "prodigy.com", "CompuServe.com");
        private static final int MINIMUM_IE_VERSION = 9;

        void throwIfInvalidSpeaker(Speaker speaker) throws BaseException {
            validatePersonalData(speaker);

            List<Session> speakerSessions = speaker.getSessions();
            if (speakerSessions.isEmpty()) {
                throw new ArgumentNullException("Can't register speaker with no sessions to present");
            }

            boolean hasFailedQualificationCriteria = !isSpeakerExceptional(speaker) && hasRedFlags(speaker);

            if (hasFailedQualificationCriteria) {
                throw new SpeakerDoesntMeetRequirementsException("Speaker doesn't meet our standards");
            }

            approveSessions(speakerSessions);

            boolean noSessionApproved = speakerSessions.stream().noneMatch(Session::isApproved);
            if (noSessionApproved) {
                throw new NoSessionsApprovedException("No sessions approved");
            }
        }

        private static void validatePersonalData(Speaker speaker) throws ArgumentNullException {
            if (!StringUtils.hasLength(speaker.getFirstName())) {
                throw new ArgumentNullException("First Name is required");
            }
            if (!StringUtils.hasLength(speaker.getLastName())) {
                throw new ArgumentNullException("Last name is required");
            }
            if (!StringUtils.hasLength(speaker.getEmail())) {
                throw new ArgumentNullException("Email is required");
            }
        }

        private static boolean isSpeakerExceptional(Speaker speaker) {
            if (10 < speaker.getExp()) {
                return true;
            }

            if (speaker.isHasBlog()) {
                return true;
            }

            if (3 < speaker.getCertifications().size()) {
                return true;
            }

            return PREFERRED_EMPLOYERS.contains(speaker.getEmployer());
        }

        private static boolean hasRedFlags(Speaker speaker) {
            String emailDomain = speaker.getEmail().split("@")[1];

            boolean isEmailDomainAncient = ANCIENT_DOMAINS.contains(emailDomain);

            WebBrowser browser = speaker.getBrowser();
            boolean isInternetExplorer = WebBrowser.BrowserName.INTERNET_EXPLORER == speaker.getBrowser().getName();
            boolean isBrowserIeAndOlderThan9 = isInternetExplorer && MINIMUM_IE_VERSION > browser.getMajorVersion();

            return isEmailDomainAncient || isBrowserIeAndOlderThan9;
        }

        private static void approveSessions(List<Session> sessions) {
            for (Session session : sessions) {
                boolean sessionNotAboutOldTechnology = !isSessionAboutOldTechnology(session);
                session.setApproved(sessionNotAboutOldTechnology);
            }

        }

        private static boolean isSessionAboutOldTechnology(Session session) {
            return OLD_TECHNOLOGIES.stream().anyMatch(tech -> session.getTitle().contains(tech) || session.getDescription().contains(tech));
        }
    }
}