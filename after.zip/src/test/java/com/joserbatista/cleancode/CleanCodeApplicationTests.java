package com.joserbatista.cleancode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CleanCodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
